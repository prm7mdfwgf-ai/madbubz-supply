MADBUBZ.SUPPLY — Product Check demo

Isi:
- index.html: halaman verifikasi yang otomatis memeriksa kode dari URL.
- QR link contoh (setelah GitHub Pages aktif):
  https://USERNAME.github.io/madbubz-supply/?code=MDBZ-0001
  https://USERNAME.github.io/madbubz-supply/?code=MDBZ-0002
  https://USERNAME.github.io/madbubz-supply/?code=MDBZ-0003

PENTING:
Ini demo statis. Kode ada di file publik sehingga bisa disalin; belum cukup untuk menjamin anti-pemalsuan.
Untuk produksi, gunakan kode unik per item dan backend/database, idealnya dengan token acak dan pemantauan pemindaian.
